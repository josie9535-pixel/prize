/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Web Audio API를 활용한 효과음 발생기 (의존성 없는 안전한 청각 피드백)
class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private getContext(): AudioContext | null {
    if (this.isMuted) return null;
    try {
      if (!this.ctx) {
        const AudioContextClass =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        if (!AudioContextClass) return null;
        this.ctx = new AudioContextClass();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    } catch {
      return null;
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // 👍 좋아요 스탬프 찍을 때의 통통 튀는 경쾌한 피치 사운드
  public playStampSound() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);

      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.2);
    } catch (e) {
      console.warn('Stamp sound error ignored:', e);
    }
  }

  // 스탬프 취소할 때의 부드러운 사운드
  public playCancelSound() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(350, now);
      osc.frequency.linearRampToValueAtTime(240, now + 0.1);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.12);
    } catch (e) {
      console.warn('Cancel sound error ignored:', e);
    }
  }

  // ⭐ 차시 완료 & 스타 획득 팡파레!
  public playStarFanfare() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      const startTime = ctx.currentTime;

      notes.forEach((freq, idx) => {
        const noteTime = startTime + idx * 0.12;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteTime);

        gain.gain.setValueAtTime(0.3, noteTime);
        gain.gain.exponentialRampToValueAtTime(0.01, noteTime + 0.28);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(noteTime);
        osc.stop(noteTime + 0.3);
      });

      // 마지막 롱 스타 징글
      setTimeout(() => {
        try {
          const finalCtx = this.getContext();
          if (!finalCtx) return;
          const finalTime = finalCtx.currentTime;
          const osc = finalCtx.createOscillator();
          const gain = finalCtx.createGain();

          osc.type = 'sine';
          osc.frequency.setValueAtTime(1318.5, finalTime); // E6
          gain.gain.setValueAtTime(0.35, finalTime);
          gain.gain.exponentialRampToValueAtTime(0.01, finalTime + 0.6);

          osc.connect(gain);
          gain.connect(finalCtx.destination);

          osc.start(finalTime);
          osc.stop(finalTime + 0.65);
        } catch {
          // ignore
        }
      }, 450);
    } catch (e) {
      console.warn('Star fanfare sound error ignored:', e);
    }
  }

  // 🎮 30개 달성! 닌텐도 게임 쿠폰 획득 웅장한 승리 팡파레
  public playNintendoCouponFanfare() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const melody = [
        { f: 392.0, d: 0.12 }, // G4
        { f: 523.25, d: 0.12 }, // C5
        { f: 659.25, d: 0.12 }, // E5
        { f: 783.99, d: 0.14 }, // G5
        { f: 1046.5, d: 0.2 }, // C6
        { f: 1318.51, d: 0.2 }, // E6
        { f: 1567.98, d: 0.5 }, // G6
      ];

      let t = ctx.currentTime;
      melody.forEach((note) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note.f, t);

        gain.gain.setValueAtTime(0.35, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + note.d);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(t);
        osc.stop(t + note.d + 0.05);

        t += note.d * 0.9;
      });
    } catch (e) {
      console.warn('Coupon fanfare sound error ignored:', e);
    }
  }
}

export const soundManager = new SoundManager();
