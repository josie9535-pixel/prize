/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Gamepad2,
  X,
  Check,
  Calendar,
  Sparkles,
  Ticket,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { Student, NintendoCoupon } from '../types';

interface Props {
  isOpen: boolean;
  student: Student;
  onClose: () => void;
  onConsumeCoupon: (couponId: string) => void;
}

export const CouponBoxModal: React.FC<Props> = ({
  isOpen,
  student,
  onClose,
  onConsumeCoupon,
}) => {
  const [confirmConsumeId, setConfirmConsumeId] = useState<string | null>(null);

  if (!isOpen) return null;

  const coupons = student.coupons || [];
  const activeCoupons = coupons.filter((c) => !c.isUsed);
  const usedCoupons = coupons.filter((c) => c.isUsed);

  const handleConfirmConsume = (couponId: string) => {
    onConsumeCoupon(couponId);
    setConfirmConsumeId(null);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-lg bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border-2 border-slate-200 overflow-hidden flex flex-col max-h-[85vh]"
        >
          {/* 헤더 */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-500 to-rose-600 flex items-center justify-center shadow-md shadow-red-500/20">
                <Gamepad2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  {student.name}의 닌텐도 쿠폰함
                </h3>
                <p className="text-xs text-slate-500">
                  사용 가능한 쿠폰{' '}
                  <strong className="text-red-600 font-extrabold">
                    {activeCoupons.length}장
                  </strong>
                  {' · '}
                  사용 완료 {usedCoupons.length}장
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-400 hover:text-slate-600 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* 쿠폰 리스트 스크롤 영역 */}
          <div className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-1">
            {coupons.length === 0 ? (
              <div className="text-center py-12 px-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-2 text-2xl">
                  ⭐
                </div>
                <h4 className="text-sm font-extrabold text-slate-700">
                  아직 발급된 닌텐도 쿠폰이 없습니다
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                  행동 목표에 스탬프를 찍어 ⭐ 스타 30개를 모으면 닌텐도 게임 쿠폰 1장이 자동으로 지급됩니다!
                </p>
              </div>
            ) : (
              coupons.map((coupon) => {
                const isConfirming = confirmConsumeId === coupon.id;

                return (
                  <div
                    key={coupon.id}
                    className={`relative rounded-2xl p-4 border-2 transition shadow-sm overflow-hidden ${
                      coupon.isUsed
                        ? 'bg-slate-50/90 border-slate-200 opacity-75'
                        : 'bg-gradient-to-r from-red-500/5 via-white to-sky-500/5 border-red-300 shadow-red-500/5'
                    }`}
                  >
                    {/* 상단 뱃지 및 코드 */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Ticket
                          className={`w-4 h-4 ${
                            coupon.isUsed ? 'text-slate-400' : 'text-red-500'
                          }`}
                        />
                        <span className="text-xs font-mono font-bold text-slate-600">
                          {coupon.code}
                        </span>
                      </div>

                      {coupon.isUsed ? (
                        <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-600">
                          소진 완료
                        </span>
                      ) : (
                        <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-emerald-500 text-white shadow-xs animate-pulse">
                          사용 가능
                        </span>
                      )}
                    </div>

                    {/* 쿠폰 타이틀 & 발급정보 */}
                    <div className="mt-2">
                      <h4
                        className={`text-base font-black ${
                          coupon.isUsed
                            ? 'text-slate-500 line-through'
                            : 'text-slate-900'
                        }`}
                      >
                        {coupon.title}
                      </h4>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          발급: {coupon.issuedAt.slice(0, 10)}
                        </span>
                        {coupon.isUsed && coupon.usedAt && (
                          <span className="text-slate-500 font-semibold">
                            (소진: {coupon.usedAt.slice(0, 10)})
                          </span>
                        )}
                      </div>
                    </div>

                    {/* 쿠폰 소진(사용하기) 영역 */}
                    {!coupon.isUsed && (
                      <div className="mt-3.5 pt-3 border-t border-slate-100">
                        {isConfirming ? (
                          <div className="flex items-center justify-between gap-2 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                            <span className="text-xs font-bold text-amber-900 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                              정말 쿠폰을 소진할까요?
                            </span>
                            <div className="flex gap-1.5 shrink-0">
                              <button
                                onClick={() => handleConfirmConsume(coupon.id)}
                                className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs shadow-sm cursor-pointer"
                              >
                                소진 확인
                              </button>
                              <button
                                onClick={() => setConfirmConsumeId(null)}
                                className="px-2 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold cursor-pointer"
                              >
                                취소
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            onClick={() => setConfirmConsumeId(coupon.id)}
                            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white font-black text-xs shadow-md shadow-red-500/20 active:scale-98 transition flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Gamepad2 className="w-4 h-4" />
                            <span>쿠폰 소진하기 (게임 1회 사용)</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* 하단 닫기 */}
          <div className="pt-3 border-t border-slate-100">
            <button
              onClick={onClose}
              className="w-full py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm transition cursor-pointer"
            >
              닫기
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
