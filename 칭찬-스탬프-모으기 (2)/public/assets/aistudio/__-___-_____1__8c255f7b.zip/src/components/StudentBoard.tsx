/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Star, Gamepad2, Sparkles, Award, ArrowRight } from 'lucide-react';
import { Student } from '../types';
import { CuteStarCharacter } from './CuteStarCharacter';

interface Props {
  student: Student;
  onSwitchToTeacher: () => void;
  onOpenCouponBox: () => void;
  onOpenEditProfile: () => void;
}

export const StudentBoard: React.FC<Props> = ({
  student,
  onSwitchToTeacher,
  onOpenCouponBox,
  onOpenEditProfile,
}) => {
  const targetStars = 30;
  const currentStars = student.totalStars;
  const remaining = Math.max(0, targetStars - currentStars);
  const progressPercent = Math.min(100, Math.round((currentStars / targetStars) * 100));
  const activeCouponsCount = (student.coupons || []).filter((c) => !c.isUsed).length;

  return (
    <div className="w-full pb-6">
      {/* 모바일: 1열 세로 스택 / 태블릿·PC: 2열 가로 그리드 분할 */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
        {/* === [좌측 영역 (모바일: 상단, PC: 좌측 5/12)] === */}
        <div className="md:col-span-5 space-y-4">
          {/* 학생 인사 카드 */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full bg-white/95 backdrop-blur rounded-3xl p-4 sm:p-5 shadow-sm border-2 border-amber-200/80 flex items-center justify-between"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <button
                onClick={onOpenEditProfile}
                title="프로필 수정 (관리자 비밀번호)"
                className="w-14 h-14 rounded-2xl bg-amber-100 flex items-center justify-center text-3xl shadow-inner border border-amber-200 cursor-pointer hover:scale-105 transition shrink-0"
              >
                {student.avatar}
              </button>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold whitespace-nowrap shrink-0">
                    {student.className}
                  </span>
                  <span className="text-xs text-slate-400 font-medium whitespace-nowrap shrink-0">{student.grade}학년</span>
                </div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight whitespace-nowrap truncate">
                    {student.name}의 보물함
                  </h2>
                </div>
              </div>
            </div>

            {/* 닌텐도 쿠폰함 열기 버튼 */}
            <button
              onClick={onOpenCouponBox}
              className={`flex flex-col items-center px-3.5 py-2 rounded-2xl border transition active:scale-95 cursor-pointer shrink-0 whitespace-nowrap ${
                activeCouponsCount > 0
                  ? 'bg-gradient-to-r from-red-500 to-rose-600 text-white border-red-400 shadow-md shadow-red-500/20 animate-pulse'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Gamepad2 className="w-5 h-5 mb-0.5" />
              <span className="text-[11px] font-black whitespace-nowrap">
                {activeCouponsCount > 0 ? `쿠폰 ${activeCouponsCount}장` : '쿠폰함'}
              </span>
            </button>
          </motion.div>

          {/* 🌟 메인 대형 스타 비주얼 카드 🌟 */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full bg-gradient-to-b from-amber-400 via-amber-300 to-yellow-200 rounded-3xl p-6 sm:p-7 shadow-xl border-4 border-yellow-300 text-center relative overflow-hidden"
          >
            {/* 반짝이 배경 애니메이션 */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/40 via-transparent to-transparent pointer-events-none" />

            <div className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full bg-white/80 backdrop-blur text-amber-900 font-extrabold text-xs sm:text-sm shadow-sm mb-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>🌟 나의 칭찬 스타 🌟</span>
            </div>

            {/* 커다란 골드 스타 캐릭터 비주얼 (정면 응시) */}
            <div className="relative my-3 flex items-center justify-center">
              <CuteStarCharacter size="xl" animate={true} />
            </div>

            {/* 스타 숫자 카운트 (예: 12 / 30) */}
            <div className="mt-2">
              <div className="flex items-baseline justify-center gap-2">
                <span className="text-5xl sm:text-6xl font-black text-amber-950 tracking-tight drop-shadow-sm">
                  {currentStars}
                </span>
                <span className="text-2xl font-bold text-amber-800/80">
                  / {targetStars}
                </span>
              </div>
            </div>

            {/* 진행률 게이지 바 */}
            <div className="mt-4 w-full bg-amber-900/15 rounded-full p-1 border-2 border-white/60">
              <div className="w-full h-4 bg-white/70 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                  className="h-full bg-gradient-to-r from-orange-400 via-amber-400 to-yellow-400 rounded-full shadow-md"
                />
              </div>
            </div>

            {/* 다음 보상 안내 텍스트 (물결 밑줄 없음) */}
            <div className="mt-4 bg-white/95 backdrop-blur rounded-2xl py-3 px-4 shadow-sm border border-amber-200 inline-block w-full">
              {remaining > 0 ? (
                <p className="text-sm sm:text-base font-extrabold text-slate-800">
                  스타 <span className="text-amber-600 font-black text-lg">{remaining}개</span>를 더 모으면{' '}
                  <span className="text-red-600 inline-flex items-center gap-1 font-black">
                    <Gamepad2 className="w-4 h-4 inline" /> 닌텐도 게임 쿠폰!
                  </span>
                </p>
              ) : (
                <p className="text-base font-black text-red-600 animate-pulse">
                  🎉 30개 달성 완료! 🎮 닌텐도 게임 쿠폰 발급!
                </p>
              )}
            </div>
          </motion.div>

          {/* 교사 화면 바로가기 버튼 */}
          <button
            onClick={onSwitchToTeacher}
            className="w-full py-3.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-sm shadow-md active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>선생님 수업 차시 기록 화면으로 이동</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* === [우측 영역 (모바일: 하단, PC: 우측 7/12 - 30칸 스타 수집판)] === */}
        <div className="md:col-span-7 space-y-4">
          <div className="w-full bg-white rounded-3xl p-5 sm:p-7 shadow-sm border-2 border-amber-200/60">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h3 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" />
                칭찬 스타 30개 모음판
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-black px-3 py-1 rounded-full bg-amber-100 text-amber-800">
                  {progressPercent}% 달성
                </span>
              </div>
            </div>

            {/* 30개 별 슬롯 (태블릿/PC에서 넉넉하고 시원하게 6열 x 5행 배치) */}
            <div className="grid grid-cols-6 gap-2 sm:gap-3.5">
              {Array.from({ length: 30 }).map((_, idx) => {
                const isFilled = idx < currentStars;
                const isMilestone = idx + 1 === 30;
                return (
                  <motion.div
                    key={idx}
                    whileHover={{ scale: 1.08 }}
                    className={`aspect-square rounded-2xl flex flex-col items-center justify-center relative transition-all duration-200 ${
                      isFilled
                        ? 'bg-gradient-to-tr from-amber-100 via-amber-50 to-yellow-100 border-2 border-amber-400 shadow-sm'
                        : isMilestone
                        ? 'bg-rose-50 border-2 border-dashed border-red-300'
                        : 'bg-slate-50/80 border-2 border-dashed border-slate-200'
                    }`}
                  >
                    {isFilled ? (
                      <Star className="w-6 h-6 sm:w-8 sm:h-8 text-amber-500 fill-amber-400 stroke-amber-600 stroke-[1.5] filter drop-shadow-xs" />
                    ) : isMilestone ? (
                      <div className="flex flex-col items-center text-center">
                        <Gamepad2 className="w-5 h-5 sm:w-7 sm:h-7 text-red-500 animate-bounce" />
                        <span className="text-[9px] font-black text-red-600 mt-0.5">30 보상</span>
                      </div>
                    ) : (
                      <span className="text-xs sm:text-sm font-extrabold text-slate-300">
                        {idx + 1}
                      </span>
                    )}
                  </motion.div>
                );
              })}
            </div>

            {/* 보상 설명 배너 */}
            <div className="mt-5 bg-gradient-to-r from-red-500/10 via-amber-500/10 to-sky-500/10 rounded-2xl p-4 border border-red-200/60 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-500 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <Gamepad2 className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-black text-slate-900">
                    30번째 별을 채우면 닌텐도 게임 쿠폰 자동 지급!
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    쿠폰이 발급되면 별은 0개부터 다시 모으고, 쿠폰함에서 언제든 사용 및 소진할 수 있습니다.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
