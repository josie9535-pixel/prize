/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';

interface Props {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  animate?: boolean;
}

export const CuteStarCharacter: React.FC<Props> = ({
  size = 'lg',
  className = '',
  animate = true,
}) => {
  // 크기별 픽셀 치수
  const dimMap = {
    sm: { w: 64, h: 64, eyeW: 4, eyeH: 9, eyeGap: 10, eyeTop: 24, cheekW: 8, cheekH: 4, cheekTop: 31, cheekOffset: 16 },
    md: { w: 96, h: 96, eyeW: 6, eyeH: 14, eyeGap: 16, eyeTop: 36, cheekW: 10, cheekH: 6, cheekTop: 47, cheekOffset: 24 },
    lg: { w: 144, h: 144, eyeW: 8, eyeH: 20, eyeGap: 24, eyeTop: 54, cheekW: 14, cheekH: 8, cheekTop: 70, cheekOffset: 36 },
    xl: { w: 180, h: 180, eyeW: 10, eyeH: 26, eyeGap: 30, eyeTop: 68, cheekW: 18, cheekH: 10, cheekTop: 88, cheekOffset: 45 },
  };

  const dim = dimMap[size];

  const content = (
    <div
      style={{ width: `${dim.w}px`, height: `${dim.h}px` }}
      className={`relative select-none flex items-center justify-center ${className}`}
    >
      {/* 5각 황금 별 본체 (SVG로 완벽한 좌우 대칭 형태) */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full drop-shadow-xl"
        style={{ filter: 'drop-shadow(0 8px 16px rgba(245, 158, 11, 0.45))' }}
      >
        <defs>
          <linearGradient id="starGoldGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFF275" />
            <stop offset="50%" stopColor="#FFD13B" />
            <stop offset="100%" stopColor="#FFAE00" />
          </linearGradient>
          <linearGradient id="starHighlight" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* 대칭 5각 별 패스 */}
        <path
          d="M 50,4
             L 63.5,33
             L 95,36.5
             L 71.5,58
             L 78,89.5
             L 50,73.5
             L 22,89.5
             L 28.5,58
             L 5,36.5
             L 36.5,33
             Z"
          fill="url(#starGoldGradient)"
          stroke="#E69500"
          strokeWidth="3"
          strokeLinejoin="round"
        />

        {/* 상단 볼륨 하이라이트 광택 */}
        <path
          d="M 50,7
             L 62,33
             L 88,36
             L 68,54
             C 55,42 45,42 32,54
             L 12,36
             L 38,33
             Z"
          fill="url(#starHighlight)"
          opacity="0.5"
        />

        {/* 정중앙 정면을 바라보는 까만 눈동자 (좌우 완벽 대칭) */}
        {/* 왼쪽 눈 */}
        <ellipse
          cx="42"
          cy="52"
          rx="3.5"
          ry="8.5"
          fill="#1E293B"
        />
        {/* 왼쪽 눈 반짝이 하이라이트 */}
        <circle
          cx="41"
          cy="48"
          r="1.4"
          fill="#FFFFFF"
        />

        {/* 오른쪽 눈 */}
        <ellipse
          cx="58"
          cy="52"
          rx="3.5"
          ry="8.5"
          fill="#1E293B"
        />
        {/* 오른쪽 눈 반짝이 하이라이트 */}
        <circle
          cx="57"
          cy="48"
          r="1.4"
          fill="#FFFFFF"
        />

        {/* 귀여운 미소 입 (정중앙 50px 기준) */}
        <path
          d="M 46,62 Q 50,66 54,62"
          fill="none"
          stroke="#1E293B"
          strokeWidth="2"
          strokeLinecap="round"
        />

        {/* 분홍빛 볼 홍조 (좌우 대칭) */}
        <ellipse
          cx="33"
          cy="58"
          rx="4.5"
          ry="2.5"
          fill="#FB7185"
          opacity="0.85"
        />
        <ellipse
          cx="67"
          cy="58"
          rx="4.5"
          ry="2.5"
          fill="#FB7185"
          opacity="0.85"
        />
      </svg>
    </div>
  );

  if (!animate) {
    return content;
  }

  return (
    <motion.div
      animate={{
        y: [0, -8, 0],
        rotate: [0, 1.5, -1.5, 0],
      }}
      transition={{
        repeat: Infinity,
        duration: 3,
        ease: 'easeInOut',
      }}
    >
      {content}
    </motion.div>
  );
};
