/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { Sparkles, Trophy, CheckCircle2, X } from 'lucide-react';
import { Student } from '../types';
import { soundManager } from '../utils/sound';
import { CuteStarCharacter } from './CuteStarCharacter';

interface Props {
  isOpen: boolean;
  student: Student;
  sessionTitle: string;
  onClose: () => void;
}

export const StarCelebrationModal: React.FC<Props> = ({
  isOpen,
  student,
  sessionTitle,
  onClose,
}) => {
  useEffect(() => {
    if (isOpen) {
      try {
        soundManager.playStarFanfare();
      } catch (err) {
        console.warn('Sound playback error:', err);
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const remaining = Math.max(0, 30 - student.totalStars);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[999] flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm transition-opacity duration-300"
    >
      {/* 팝업 모달 본체 */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-gradient-to-b from-amber-50 via-white to-amber-100/95 rounded-3xl p-6 sm:p-7 shadow-2xl border-4 border-amber-400 text-center overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        {/* 우측 상단 닫기 X 버튼 */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center transition cursor-pointer z-20 shadow-xs"
        >
          <X className="w-5 h-5" />
        </button>

        {/* 상단 팡파레 뱃지 */}
        <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-amber-500 text-white font-extrabold text-xs sm:text-sm shadow-md mb-2">
          <Sparkles className="w-4 h-4 animate-spin" />
          <span>차시 목표 100% 달성 완료!</span>
        </div>

        <p className="text-xs sm:text-sm font-semibold text-slate-500 mt-0.5">
          {sessionTitle}
        </p>

        {/* 중앙 거대 별 획득 비주얼 (정면 응시 캐릭터) */}
        <div className="relative my-4 flex items-center justify-center">
          {/* 부드러운 골드 후광 백그라운드 */}
          <div className="absolute w-36 h-36 bg-amber-300/60 rounded-full blur-xl pointer-events-none" />

          {/* 대칭 정면 별 캐릭터 */}
          <div className="relative z-10 filter drop-shadow-xl transform hover:scale-105 transition-transform duration-300">
            <CuteStarCharacter size="xl" animate={false} />
          </div>

          {/* 학생 아바타 이모지 뱃지 */}
          <div className="absolute -bottom-1 right-8 text-4xl filter drop-shadow-md select-none transform hover:scale-110 transition-transform">
            {student.avatar || '🦁'}
          </div>
        </div>

        {/* 축하 타이틀 */}
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-amber-950 tracking-tight">
            ⭐ 스타 1개 획득!
          </h2>
          <p className="text-base sm:text-lg font-bold text-amber-700 mt-1">
            참 잘했어요, <span className="text-slate-900 font-black">{student.name}</span> 학생!
          </p>
        </div>

        {/* 누적 스타 현황 및 30개 보상 안내 카드 */}
        <div className="mt-4 bg-white/95 rounded-2xl p-4 border border-amber-200 shadow-sm text-left">
          <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-700 mb-2">
            <span className="flex items-center gap-1.5 text-amber-700">
              <Trophy className="w-4 h-4 text-amber-500" />
              현재 누적 스타
            </span>
            <span className="text-lg text-amber-600 font-black">
              {student.totalStars} <span className="text-xs text-slate-400">/ 30</span>
            </span>
          </div>

          {/* 진행률 바 */}
          <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
            <div
              style={{ width: `${Math.min(100, Math.max(5, (student.totalStars / 30) * 100))}%` }}
              className="h-full bg-gradient-to-r from-amber-400 to-yellow-400 rounded-full transition-all duration-700"
            />
          </div>

          <p className="text-xs text-slate-600 mt-2 font-medium">
            {remaining > 0 ? (
              <>
                스타 <strong className="text-amber-600 font-black">{remaining}개</strong>를 더 모으면{' '}
                <span className="font-extrabold text-red-600">🎮 닌텐도 게임 쿠폰</span>을 받아요!
              </>
            ) : (
              <span className="font-bold text-red-600">
                🎉 축하합니다! 30개 달성으로 닌텐도 게임 쿠폰이 발급되었습니다!
              </span>
            )}
          </p>
        </div>

        {/* 하단 확인 버튼 */}
        <div className="mt-5">
          <button
            onClick={onClose}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white font-extrabold text-base shadow-lg shadow-amber-500/30 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>멋져요! 확인</span>
          </button>
        </div>
      </div>
    </div>
  );
};
