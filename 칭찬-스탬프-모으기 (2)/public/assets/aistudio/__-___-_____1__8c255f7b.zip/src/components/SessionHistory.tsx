/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Star, CheckCircle2, ChevronDown, ChevronUp, History, User } from 'lucide-react';
import { Student, Session } from '../types';

interface Props {
  student: Student;
  sessions: Session[];
}

export const SessionHistory: React.FC<Props> = ({ student, sessions }) => {
  const [expandedSessionId, setExpandedSessionId] = useState<string | null>(null);

  // 현재 학생에 해당하는 세션 중 오직 스타를 획득한 완료 차시만 필터링 (최신순)
  const studentSessions = sessions
    .filter((s) => s.studentId === student.id && s.starAwarded)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const completedCount = studentSessions.filter((s) => s.completed).length;
  const remaining = Math.max(0, 30 - student.totalStars);

  const toggleExpand = (id: string) => {
    setExpandedSessionId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="flex flex-col w-full py-2 space-y-4">
      {/* 1. 학생 성취 요약 카드 (기획서 9장 예시 반영) */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-800 to-indigo-950 text-white rounded-3xl p-5 shadow-lg border border-indigo-700/50">
        <div className="flex items-center justify-between pb-3 border-b border-indigo-800/80">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">{student.avatar}</span>
            <div>
              <h3 className="text-lg font-black">{student.name} 학생 성취 기록</h3>
              <p className="text-xs text-indigo-300 font-medium">
                {student.className} · {student.grade}학년
              </p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 font-semibold">
            누적 기록
          </span>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-4 text-center">
          <div className="bg-white/10 rounded-2xl p-3 border border-white/10">
            <p className="text-[11px] text-indigo-200 font-semibold">총 스타</p>
            <p className="text-xl font-black text-amber-300 mt-0.5 flex items-center justify-center gap-1">
              ⭐ {student.totalStars}
            </p>
          </div>
          <div className="bg-white/10 rounded-2xl p-3 border border-white/10">
            <p className="text-[11px] text-indigo-200 font-semibold">완료 차시</p>
            <p className="text-xl font-black text-emerald-300 mt-0.5">
              {completedCount}회
            </p>
          </div>
          <div className="bg-white/10 rounded-2xl p-3 border border-white/10">
            <p className="text-[11px] text-indigo-200 font-semibold">30개까지</p>
            <p className="text-xl font-black text-rose-300 mt-0.5">
              {remaining}개
            </p>
          </div>
        </div>
      </div>

      {/* 2. 최근 차시 기록 목록 */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200">
        <div className="flex items-center justify-between mb-3 px-1">
          <h4 className="text-sm font-extrabold text-slate-800 flex items-center gap-1.5">
            <History className="w-4 h-4 text-slate-500" />
            최근 스타 획득 완료 기록 ({studentSessions.length}건)
          </h4>
        </div>

        {studentSessions.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-xs">
            아직 완료된 차시 기록이 없습니다.
            <br />
            스탬프를 모두 모아 ⭐ 스타를 획득하면 이곳에 기록이 남습니다!
          </div>
        ) : (
          <div className="space-y-2.5">
            {studentSessions.map((session) => {
              const isExpanded = expandedSessionId === session.id;
              const dateDisplay = session.date.slice(5).replace('-', '/');
              const stampsAwarded = session.stamps.filter((s) => s.awarded).length;
              const totalStamps = session.stamps.length;

              return (
                <div
                  key={session.id}
                  className="border border-slate-200 rounded-2xl overflow-hidden hover:border-slate-300 transition"
                >
                  <div
                    onClick={() => toggleExpand(session.id)}
                    className="p-3.5 bg-slate-50/70 hover:bg-slate-100/70 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-bold text-slate-500 bg-white px-2 py-1 rounded-lg border border-slate-200">
                        {dateDisplay}
                      </span>
                      <span className="text-xs font-extrabold text-slate-700 bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md">
                        {session.period}교시
                      </span>
                      <span className="text-sm font-bold text-slate-900">
                        {session.templateName}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      {session.starAwarded ? (
                        <span className="inline-flex items-center gap-1 text-xs font-black text-amber-600 bg-amber-100 px-2 py-1 rounded-full">
                          <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                          스타 획득
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 font-medium">
                          {stampsAwarded}/{totalStamps} 진행중
                        </span>
                      )}
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </div>

                  {/* 세부 스탬프 달성 내역 아코디언 */}
                  {isExpanded && (
                    <div className="p-3 bg-white border-t border-slate-100 space-y-1.5">
                      <div className="text-[11px] text-slate-400 flex items-center justify-between mb-2">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" /> 담당교사: {session.teacherName}
                        </span>
                        <span>
                          {session.completed ? '전 항목 완료' : `${stampsAwarded}개 달성`}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {session.stamps.map((st, i) => (
                          <div
                            key={i}
                            className={`flex items-center justify-between text-xs p-2 rounded-xl border ${
                              st.awarded
                                ? 'bg-amber-50/50 border-amber-200 text-slate-800'
                                : 'bg-slate-50 border-slate-100 text-slate-400 line-through'
                            }`}
                          >
                            <span className="truncate pr-1">{st.behaviorName}</span>
                            {st.awarded ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                            ) : (
                              <span className="text-[10px] text-slate-300">미달성</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
